# Restaurant Order & Table Management System (Java Console Backend)

A Java console application demonstrating key Data Structures & Algorithms (DSA) concepts for restaurant order and table management.

## 🚀 Key Features & Data Structures

1. **Custom Linked-List Queue (`ds.CustomQueue<T>`)**:
   - **DSA Requirement**: Custom node-based FIFO queue implementation without using `java.util.Queue` or Java collection queues.
   - Used for the **Customer Waiting Line** when all tables are occupied.
   - $O(1)$ Enqueue & Dequeue operations.

2. **HashMap Table Orders (`Map<Integer, List<OrderItem>>`)**:
   - **DSA Requirement**: `HashMap` mapping table numbers (Integer) to their active ordered items list.
   - Supports adding items, calculating itemized subtotal, tax (5%), service charge (5%), and grand total.

3. **Table Management & Auto-Assignment**:
   - Walk-in customers are assigned to available tables.
   - If tables are full, walk-ins are automatically placed into the `CustomQueue` waiting line.
   - When a table is checked out and vacated, the system automatically dequeues the front customer from `CustomQueue` and assigns them to the newly freed table.

---

## 📁 Directory Structure

```
restaurant_app/
├── bin/                       # Compiled Java bytecode (.class files)
├── src/
│   ├── ds/
│   │   ├── Node.java          # Generic singly-linked list node
│   │   └── CustomQueue.java   # Custom FIFO Queue using linked list
│   ├── model/
│   │   ├── Customer.java      # Customer entity (ID, Name, Party size)
│   │   ├── MenuItem.java      # Menu Item entity (ID, Name, Category, Price)
│   │   ├── OrderItem.java     # Order line item with quantity
│   │   └── Table.java         # Table state (Table #, Capacity, Customer)
│   ├── service/
│   │   └── RestaurantManager.java # Core backend business logic
│   ├── Main.java              # Interactive Terminal App entry point
│   └── TestRunner.java        # Automated verification unit tests
├── run.bat                    # Windows Batch script to compile & run
├── run.ps1                    # PowerShell script to compile & run
└── README.md                  # Project documentation
```

---

## 💻 How to Run

### Option 1: Run via Provided Scripts (Recommended)

**On Windows Command Prompt / Terminal:**
```cmd
cd restaurant_app
run.bat
```

**On PowerShell:**
```powershell
cd restaurant_app
.\run.ps1
```

### Option 2: Manual Terminal Compilation & Execution

```bash
cd restaurant_app

# 1. Compile all Java sources into 'bin' directory
javac -d bin src/ds/*.java src/model/*.java src/service/*.java src/Main.java src/TestRunner.java

# 2. Run Interactive Console App
java -cp bin Main

# 3. Run Automated Tests
java -cp bin TestRunner
```

---

## 🧪 Automated Tests

Run `java -cp bin TestRunner` to execute automated test cases validating:
1. `CustomQueue` FIFO ordering, enqueue, dequeue, peek, and size methods.
2. Walk-in table routing and automatic placement into `CustomQueue` when tables are full.
3. Order placement and retrieval via `HashMap<Integer, List<OrderItem>>`.
4. Table checkout, bill receipt formatting, table freeing, and automatic customer dequeuing + assignment.
