package model;

public class MenuItem {
    private int id;
    private String name;
    private String category;
    private double price;

    public MenuItem(int id, String name, String category, double price) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return String.format("[%d] %-25s (%-10s) - $%.2f", id, name, category, price);
    }
}
