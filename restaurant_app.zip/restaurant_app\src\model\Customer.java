package model;

public class Customer {
    private int id;
    private String name;
    private int partySize;

    public Customer(int id, String name, int partySize) {
        this.id = id;
        this.name = name;
        this.partySize = partySize;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getPartySize() {
        return partySize;
    }

    @Override
    public String toString() {
        return "Customer #" + id + " [" + name + ", Party of " + partySize + "]";
    }
}
